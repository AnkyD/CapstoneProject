package com.infy.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.infy.dao.MobileServiceDAO;
import com.infy.dao.MobileServiceDAOImpl;
import com.infy.exception.MobileServiceException;
import com.infy.model.ServiceReport;
import com.infy.model.ServiceRequest;
import com.infy.model.Status;
import com.infy.validator.Validator;

public class MobileServiceImpl implements MobileService{
	
	private MobileServiceDAO dao =  new MobileServiceDAOImpl();

	@Override
	public ServiceRequest registerRequest(ServiceRequest service) throws MobileServiceException {
		Validator v1=new Validator();
		v1.validate(service);
		Float value=calculateEstimateCost(service.getIssues());
		
		if(value<=0) {
			throw new MobileServiceException("Sorry, we do not provide that service");
			
		}else {
			service.setServiceFee(value);
			service.setStatus(Status.ACCEPTED);
			service.setTimeOfRequest(LocalDateTime.now());
			ServiceRequest obj=dao.registerRequest(service);
			return obj;
		}
		
	}

	@Override
	public Float calculateEstimateCost(List<String> issues) throws MobileServiceException {
		float serviceFee=0;
		for(String issue:issues) {
			issue=issue.toUpperCase();
			if(issue.equals("BATTERY")) {
				serviceFee+=10;
			}
			if(issue.equals("CAMERA")) {
				serviceFee+=5;
			}
			if(issue.equals("SCREEN")) {
				serviceFee+=15;
			}
			
		}
		return serviceFee;
	}

	@Override
	public List<ServiceReport> getServices(Status status) throws MobileServiceException {
		List<ServiceReport> sr=new ArrayList<>();
	
		List<ServiceRequest> sR=dao.getServices();
		for(ServiceRequest s:sR) {
			if(s.getStatus().equals(status)) {
				ServiceReport s1=new ServiceReport(s.getServiceId(), s.getBrand(), s.getIssues(), s.getServiceFee());
				sr.add(s1);
			}
		}
		if(sr.isEmpty()) {
			throw new MobileServiceException("Sorry we did not find any record for your query");
		}
		else {
			return sr;
		}
	}

}
