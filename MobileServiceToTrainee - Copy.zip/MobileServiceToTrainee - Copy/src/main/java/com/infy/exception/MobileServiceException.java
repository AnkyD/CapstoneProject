package com.infy.exception;

public class MobileServiceException extends Exception {
	

public MobileServiceException(String message)
{
	super(message);
}
}
