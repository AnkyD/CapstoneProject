package com.infy.validator;

import java.util.List;

import com.infy.exception.MobileServiceException;
import com.infy.model.ServiceRequest;


public class Validator {

	public void validate(ServiceRequest service) throws MobileServiceException {	
		//your code goes here
		if(isValidBrand(service.getBrand())==false) {
			throw new MobileServiceException("Sorry! we do not provide service for this brand");
			
		}
		if(isValidIssues(service.getIssues())==false) {
			throw new MobileServiceException("Please provide the device only if there are any issues");
		}
		if(isValidIMEINumber(service.getiMEINumber())==false) {
			throw new MobileServiceException("Sorry! we're not able to detect the IMEI number for this device");
		}
		if(isValidContactNumber(service.getContactNumber())==false) {
			throw new MobileServiceException("Please provide a valid contact number");
		}
		if(isValidContactNumber(service.getContactNumber())==false) {
		}
	}	

	
	// validates the brand
	// brand should always start with a upper case alphabet 
	// and can be followed by one or more alphabets (lower case or upper case) 
	public Boolean isValidBrand(String brand){
		String regex="[A-Z][A-Za-z]{1,}";
		return brand.matches(regex);
	}
	
	
	// validates the list of issues
	// checks if the list is null or empty
	public Boolean isValidIssues(List<String> issues) {
		if(issues.isEmpty() || issues==null) {
			return false;
		}
		return true;
	}

	// validates the IMEINumber
	// it should be a 16 digit number 
	public Boolean isValidIMEINumber(Long iMEINumber) {
		String number=iMEINumber.toString();
		if(number.length()==16) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// validates the contact number
	// should contain 10 numeric characters and should not contain 10 repetitive characters
	public Boolean isValidContactNumber(Long contactNumber) {
		String number=contactNumber.toString();
		char firstNumber=number.substring(0,1).charAt(0);
		char[] numbers=number.toCharArray();
		boolean flag=false;
		for(char c:numbers) {
			if(c==firstNumber) {
				flag=false;
			}else {
				flag=true;
				break;
			}
		}
		if(number.length()>=10 && flag) {
			return true;
		}else {
			return false;
		}
	}
	
	
	// validates the customer name
	// should contain at least one word and each word separated by a single space should contain at least one letter.
	// the first letter of every word should be an upper case character 
	public Boolean isValidCustomerName(String customerName) {
		String[] arr=customerName.split(" ");
		if(arr.length==0) {
			return false;
		}
		String regex="[A-Z][a-z ]{2,}";
		boolean flag=false;
		for(String a:arr) {
			if(a.matches(regex)) {
				flag=true;
			}else {
				flag=false;
				break;
			}
		}
		return flag;
	}
}
