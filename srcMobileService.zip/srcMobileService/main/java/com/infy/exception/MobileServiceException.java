package com.infy.exception;

public class MobileServiceException extends Exception {
	
private static final long serialVersionUID = 9055345452217545316L;

public MobileServiceException(String message)
{
	super(message);
}
}
