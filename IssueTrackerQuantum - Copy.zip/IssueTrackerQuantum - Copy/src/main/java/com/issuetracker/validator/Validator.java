package com.issuetracker.validator;

import java.time.LocalDate;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueStatus;

//Do Not Change Any Signature
public class Validator
{
 public void validate(Issue issue) throws IssueTrackerException
 {
	// Your Code Goes Here
     if(isValidIssueId(issue.getIssueId())==false) {
	 throw new IssueTrackerException("The issue ID is of invalid format!");
     }
     if(isValidIssueDescription(issue.getIssueDescription())==false) {
	 throw new IssueTrackerException("The issue description is of unacceptable format !");
     }
     if(isValidReportedOn(issue.getReportedOn())==false) {
	 throw new IssueTrackerException("The reported date is incorrect");
     }
     if(isValidStatus(issue.getStatus())==false) {
	 throw new IssueTrackerException("The status of the issue is inappropriate");
     }
 }

 public Boolean isValidIssueId(String issueId)
 {
	// Your Code Goes Here

	if(issueId.isEmpty()||issueId==null) {
	    return false;
	}
String regex="(MTI-I-)(([0-9][0-9][1-9])|([1-9][0-9][0-9])|([0-9][1-9][0-9]))(-(LS|MS|HS))";
return issueId.matches(regex);
 }

 public Boolean isValidIssueDescription(String issueDescription)
 {
	// Your Code Goes Here
     String regex="[A-Za-z ]+";
     if(issueDescription.isBlank() || issueDescription.isEmpty() || issueDescription==null) {
	 return false;
     }
     if(issueDescription.substring(0, 1).equals(" ") || issueDescription.substring(issueDescription.length()-1,issueDescription.length()).equals(" ")) {
	 return false;
     }	
     if(issueDescription.length()>50 || issueDescription.length()<1) {
	 return false;
     }
     return issueDescription.matches(regex);
     
 }

 public Boolean isValidReportedOn(LocalDate reportedOn)
 {
	// Your Code Goes Here
     if(reportedOn.isAfter(LocalDate.now())|| reportedOn==null) {
	 return false;
     }

return true;
 }

 public Boolean isValidStatus(IssueStatus status)
 {
	// Your Code Goes Here
     String sta=status.toString().toUpperCase();
     if(sta.equals("OPEN")||sta.equals("IN_PROGRESS")) {
	 return true;
     }

	return false;
 }
}