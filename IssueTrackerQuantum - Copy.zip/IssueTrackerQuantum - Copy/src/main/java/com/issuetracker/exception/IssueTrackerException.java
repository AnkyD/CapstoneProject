package com.issuetracker.exception;

public class IssueTrackerException extends Exception {
    public IssueTrackerException(String message) {
	super(message);
    }
    
}